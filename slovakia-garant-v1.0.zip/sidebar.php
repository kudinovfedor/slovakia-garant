<?php if (is_active_sidebar('sidebar-widget-area')) : ?>
    <aside class="sidebar">
        <?php dynamic_sidebar('sidebar-widget-area'); ?>
    </aside>
<?php endif; ?>
