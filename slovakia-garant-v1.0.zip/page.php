<?php get_header(); ?>

<?php get_template_part('loops/content', 'page'); ?>

<?php get_footer(); ?>
