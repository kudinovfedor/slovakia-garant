<?php
/**
 * Template Name: Home Page
 **/
?>

<?php get_header(); ?>

<?php get_template_part('loops/content', 'home'); ?>

<?php get_footer(); ?>
