<?php

register_nav_menus(array(
    'main-nav'    => __('Main Navigation', 'brainworks'),
    'second-menu' => __('Second Menu', 'brainworks'),
));
